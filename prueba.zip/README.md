# practica_lara
Pequeña practica de laravel